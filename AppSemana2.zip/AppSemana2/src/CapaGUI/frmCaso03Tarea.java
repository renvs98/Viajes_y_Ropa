
package CapaGUI;

import CapaNegocio.ClassMetodosTarea;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableModel;

public class frmCaso03Tarea extends javax.swing.JFrame {

    String titutlo[]={"Nro","Cliente","Tipo de Prenda","Precio","Cantidad","Total"};
    String datos [][]={};
    DefaultTableModel modtbDatos=new DefaultTableModel(datos,titutlo);
    ClassMetodosTarea metodos=new ClassMetodosTarea();
    int reg=1;
    int ordenR, ordenP, cantidad; 
    double precioVenta,precioTotal,total;
    
    public frmCaso03Tarea() {
        initComponents();
        tbDatos.setModel(modtbDatos);
        ActivarRadio();
        SpinnerNumberModel Cantidad = new SpinnerNumberModel();
        Cantidad.setValue(1);
        Cantidad.setMaximum(10);
        Cantidad.setMinimum(1);
        Cantidad.setStepSize(1);
        spiCantidad.setModel(Cantidad);
        spiCantidad.addChangeListener(new javax.swing.event.ChangeListener() {
        @Override
        public void stateChanged(javax.swing.event.ChangeEvent evt) {
            spiCantidadStateChanged(evt);
            }
            private void spiCantidadStateChanged(ChangeEvent evt) {
                ordenR = cboPrenda.getSelectedIndex();
                int ordenP;
                if (rbtV.isSelected()) {
                    ordenP = 0;
                } else if (rbtD.isSelected()) {
                    ordenP = 1;
                } else {
                    ordenP = 2;
                }
    
                precioVenta = metodos.HallarPrecioVenta(ordenP, ordenR);
                cantidad = (int) spiCantidad.getValue();
                precioTotal = metodos.HallarPrecioTotal((int) precioVenta, cantidad);
    
                lblPrecioVenta.setText(String.valueOf(precioTotal));
            }
        });
    }

void ActivarRadio(){
    grpPersona.add(rbtV);
    grpPersona.add(rbtD);
    grpPersona.add(rbtN);
}

void actualizarNumerosRegistro(){
    DefaultTableModel model = (DefaultTableModel) tbDatos.getModel();
    for (int i = 0; i < model.getRowCount(); i++) {
        model.setValueAt(i + 1, i, 0);
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpPersona = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        rbtV = new javax.swing.JRadioButton();
        rbtD = new javax.swing.JRadioButton();
        rbtN = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        cboPrenda = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        lblPrecioVenta = new javax.swing.JLabel();
        spiCantidad = new javax.swing.JSpinner();
        jLabel5 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbDatos = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        lblFotoRopa = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Clientes"));

        rbtV.setText("Varones");
        rbtV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtVActionPerformed(evt);
            }
        });

        rbtD.setText("Damas");
        rbtD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtDActionPerformed(evt);
            }
        });

        rbtN.setText("Niños");
        rbtN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtNActionPerformed(evt);
            }
        });

        jLabel2.setText("Tipos de Prenda");

        cboPrenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPrendaActionPerformed(evt);
            }
        });

        jLabel3.setText("Precio de Venta");

        lblPrecioVenta.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPrecioVenta.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel5.setText("Cantidad");

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        tbDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbDatos);

        jLabel7.setFont(new java.awt.Font("Power Red and Green", 1, 36)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Tienda de Ropa \"Dancy\"");

        lblFotoRopa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFotoRopa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbtV)
                                    .addComponent(rbtN)
                                    .addComponent(rbtD))))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(cboPrenda, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPrecioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spiCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(btnAgregar)
                        .addGap(54, 54, 54)
                        .addComponent(btnEliminar))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblFotoRopa, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(rbtV))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addComponent(rbtN))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(rbtD))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(spiCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cboPrenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(lblPrecioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(63, 63, 63)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAgregar)
                            .addComponent(btnEliminar)))
                    .addComponent(lblFotoRopa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
            // Obtener los datos de los componentes de la interfaz
            String cliente = "";
            if (rbtV.isSelected()) {
                cliente = "Varones";
            } else if (rbtD.isSelected()) {
                cliente = "Damas";
            } else if (rbtN.isSelected()) {
                cliente = "Niños";
            }

            String tipoPrenda = cboPrenda.getSelectedItem().toString();
            precioVenta = Double.parseDouble(lblPrecioVenta.getText());
            cantidad = (int) spiCantidad.getValue();
            total = metodos.HallarPrecioTotal((int) precioVenta, cantidad);

            Object datosP[]={reg,cliente,tipoPrenda,precioVenta,cantidad,total};
            modtbDatos.addRow(datosP);
            ++reg;
            actualizarNumerosRegistro();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int selectedRowIndex = tbDatos.getSelectedRow();
        if(selectedRowIndex != -1) {
            DefaultTableModel model = (DefaultTableModel) tbDatos.getModel();
            model.removeRow(selectedRowIndex);
        }
        actualizarNumerosRegistro();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void rbtVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtVActionPerformed
        // TODO add your handling code here:
          metodos.ElegirPrenda(0, cboPrenda);
    }//GEN-LAST:event_rbtVActionPerformed

    private void rbtDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtDActionPerformed
        // TODO add your handling code here:
        metodos.ElegirPrenda(1, cboPrenda);
    }//GEN-LAST:event_rbtDActionPerformed

    private void rbtNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtNActionPerformed
        // TODO add your handling code here:
        metodos.ElegirPrenda(2, cboPrenda);
    }//GEN-LAST:event_rbtNActionPerformed

    private void cboPrendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboPrendaActionPerformed
        // TODO add your handling code here:
        ordenR = cboPrenda.getSelectedIndex();
        int ordenP;
        if (rbtV.isSelected()) {
            ordenP = 0;
        } else if (rbtD.isSelected()) {
            ordenP = 1;
        } else {
            ordenP = 2;
        }
        String imagen = metodos.Imagenes(ordenP, ordenR);
        metodos.Acoplar(imagen, lblFotoRopa);
        
        precioVenta = metodos.HallarPrecioVenta(ordenP, ordenR);
        lblPrecioVenta.setText(String.valueOf(precioVenta));
        
        cantidad = (int) spiCantidad.getValue();
        precioTotal = metodos.HallarPrecioTotal((int) precioVenta, cantidad);
        // Multiplicar precio de venta por cantidad y mostrarlo en lblPrecioVenta
        lblPrecioVenta.setText(String.valueOf(precioTotal));
    }//GEN-LAST:event_cboPrendaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCaso03Tarea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCaso03Tarea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCaso03Tarea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCaso03Tarea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCaso03Tarea().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> cboPrenda;
    private javax.swing.ButtonGroup grpPersona;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFotoRopa;
    private javax.swing.JLabel lblPrecioVenta;
    private javax.swing.JRadioButton rbtD;
    private javax.swing.JRadioButton rbtN;
    private javax.swing.JRadioButton rbtV;
    private javax.swing.JSpinner spiCantidad;
    private javax.swing.JTable tbDatos;
    // End of variables declaration//GEN-END:variables
}
