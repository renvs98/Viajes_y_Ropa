
package CapaGUI;

import CapaNegocio.ClassMetodosEvaluación;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

public class ActividadSem2 extends javax.swing.JFrame {
    String titutlo[]={"Nro.","Apellidos y Nombres","Tipo de Documento","Pais","Lugar Turistico","Cantidad de Personas","Total de Costo","Total a Pagar"};
    String datos [][]={};
    DefaultTableModel modtbDatos=new DefaultTableModel(datos,titutlo);
    double costoLugar,totalCostoSinDescuento,descuento,totalPagar,totalCosto;
    int cantidadP;
    int reg=1,ordenT,ordenPais;
    ClassMetodosEvaluación metodos=new ClassMetodosEvaluación();
    DefaultListModel modlstTuristico=new DefaultListModel();

    public ActividadSem2() {
        initComponents();
        tbDatos.setModel(modtbDatos);
        ActivarRadio();
        metodos.LlenarPais(cboPais);
        metodos.LlenarPersonas(cboPersonas);
        
    }

void ActivarRadio(){
    grpDocumento.add(rbtD);
    grpDocumento.add(rbtC);
    grpDocumento.add(rbtO);
}

void Calcular(){
    // Obtener el número de personas seleccionado
    cantidadP = Integer.parseInt(cboPersonas.getSelectedItem().toString());
    // Calcular el total de costo sin descuento
    totalCostoSinDescuento = metodos.TotalCosto(cantidadP, (int) costoLugar);
    lblTotalCosto.setText(String.valueOf(totalCostoSinDescuento));
    // Calcular el descuento
    descuento = metodos.Descuento((int)totalCostoSinDescuento);
    // Mostrar el descuento en lblDescuento
    lblDescuento.setText(String.valueOf(descuento));
    // Calcular y mostrar el total a pagar
    totalPagar = metodos.PagoTotal(totalCostoSinDescuento, (int)descuento);
    lblTotalPagar.setText(String.valueOf(totalPagar));
}

void actualizarNumerosRegistro(){
    //AÑADIR FILA SEGUN CLIENTE
    DefaultTableModel model = (DefaultTableModel) tbDatos.getModel();
    for (int i = 0; i < model.getRowCount(); i++) {
        model.setValueAt(i + 1, i, 0);
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grpDocumento = new javax.swing.ButtonGroup();
        lbllugares = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNombreApellido = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        rbtD = new javax.swing.JRadioButton();
        rbtC = new javax.swing.JRadioButton();
        rbtO = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstTuristico = new javax.swing.JList<>();
        jLabel5 = new javax.swing.JLabel();
        lblFoto = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cboPais = new javax.swing.JComboBox<>();
        cboPersonas = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lblCostoLugar = new javax.swing.JLabel();
        lblDescuento = new javax.swing.JLabel();
        lblTotalPagar = new javax.swing.JLabel();
        lblTotalCosto = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbDatos = new javax.swing.JTable();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbllugares.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        lbllugares.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbllugares.setText("LUGARES TURISTICOS FERSA");

        jLabel2.setText("Apellidos y Nombres");

        jLabel3.setText("Tipo de Documento");

        rbtD.setText("DNI");

        rbtC.setText("Carnet de Extranjeria");

        rbtO.setText("Otros");

        jLabel4.setText("Lugares Turisticos");

        lstTuristico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstTuristicoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(lstTuristico);

        jLabel5.setText("Foto");

        lblFoto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel7.setText("Cantidad de Personas");

        jLabel8.setText("Pais");

        cboPais.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPaisActionPerformed(evt);
            }
        });

        cboPersonas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPersonasActionPerformed(evt);
            }
        });

        jLabel9.setText("Costo por Lugar");

        jLabel10.setText("Descuento de 10%");

        jLabel11.setText("Total a Pagar");

        jLabel12.setText("Total de Costo");

        lblCostoLugar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCostoLugar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblDescuento.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDescuento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblTotalPagar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalPagar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lblTotalCosto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalCosto.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tbDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tbDatos);

        btnEliminar.setText("Eliminar Registro");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setText("Agregar Registro");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lbllugares, javax.swing.GroupLayout.PREFERRED_SIZE, 821, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jLabel9))
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(lblDescuento, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblCostoLugar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE))
                            .addComponent(lblTotalPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblTotalCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(60, 60, 60)
                                .addComponent(btnAgregar)
                                .addGap(40, 40, 40)
                                .addComponent(btnEliminar)))
                        .addGap(30, 30, 30))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(txtNombreApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(23, 23, 23)
                                .addComponent(rbtD)
                                .addGap(18, 18, 18)
                                .addComponent(rbtC)
                                .addGap(18, 18, 18)
                                .addComponent(rbtO))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addGap(18, 18, 18)
                                        .addComponent(cboPais, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel4))
                                .addGap(192, 192, 192)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(cboPersonas, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lbllugares, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel2))
                    .addComponent(txtNombreApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(rbtD)
                    .addComponent(rbtC)
                    .addComponent(rbtO))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel8))
                            .addComponent(cboPais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cboPersonas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel12)
                    .addComponent(lblTotalCosto, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(jLabel9)
                    .addComponent(lblCostoLugar, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(lblDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(lblTotalPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lstTuristicoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstTuristicoMouseClicked
        // TODO add your handling code here:
        // Obtener el índice del lugar turístico seleccionado
        ordenT = lstTuristico.getSelectedIndex();
        // Obtener la imagen del lugar turístico seleccionado
        String ximagen = metodos.MostrarImagen(cboPais.getSelectedIndex(), ordenT);
        // Mostrar la imagen en el lblFoto
        metodos.Acoplar(ximagen, lblFoto);
        // Obtener y mostrar el costo del lugar turístico seleccionado
        costoLugar = metodos.CostoLugar(cboPais.getSelectedIndex(), ordenT);
        lblCostoLugar.setText(String.valueOf(costoLugar));
        Calcular();
    }//GEN-LAST:event_lstTuristicoMouseClicked

    private void cboPaisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboPaisActionPerformed
        // TODO add your handling code here:
        modlstTuristico.clear();
        // Obtener el índice del país seleccionado
        ordenPais = cboPais.getSelectedIndex();
        // Llenar la lista de lugares turísticos según el país seleccionado
        metodos.LlenarLista(ordenPais, modlstTuristico);
        // Mostrar la lista actualizada en el lstTuristico
        lstTuristico.setModel(modlstTuristico);        
    }//GEN-LAST:event_cboPaisActionPerformed

    private void cboPersonasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboPersonasActionPerformed
        // TODO add your handling code here:
        Calcular();
    }//GEN-LAST:event_cboPersonasActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        String nombreApellido = txtNombreApellido.getText();        
        String tipoDocumento = "";
        if (rbtD.isSelected()) {
            tipoDocumento = "DNI";
        } else if (rbtC.isSelected()) {
            tipoDocumento = "Carnet de Extranjeria";
        } else if (rbtO.isSelected()) {
            tipoDocumento = "Otros";
        }
        String pais = cboPais.getSelectedItem().toString();
        String lugarTuristico = lstTuristico.getSelectedValue();
        cantidadP = Integer.parseInt(cboPersonas.getSelectedItem().toString());
        totalCosto = Double.parseDouble(lblTotalCosto.getText());
        totalPagar = Double.parseDouble(lblTotalPagar.getText());

        Object[] fila = {reg,nombreApellido, tipoDocumento, pais, lugarTuristico, cantidadP, totalCosto, totalPagar};
        modtbDatos.addRow(fila);
        ++reg;
        actualizarNumerosRegistro();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int selectedRowIndex = tbDatos.getSelectedRow();
        if(selectedRowIndex != -1) {
            DefaultTableModel model = (DefaultTableModel) tbDatos.getModel();
            model.removeRow(selectedRowIndex);
        }
        actualizarNumerosRegistro();
    }//GEN-LAST:event_btnEliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ActividadSem2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ActividadSem2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ActividadSem2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ActividadSem2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ActividadSem2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> cboPais;
    private javax.swing.JComboBox<String> cboPersonas;
    private javax.swing.ButtonGroup grpDocumento;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCostoLugar;
    private javax.swing.JLabel lblDescuento;
    private javax.swing.JLabel lblFoto;
    private javax.swing.JLabel lblTotalCosto;
    private javax.swing.JLabel lblTotalPagar;
    private javax.swing.JLabel lbllugares;
    private javax.swing.JList<String> lstTuristico;
    private javax.swing.JRadioButton rbtC;
    private javax.swing.JRadioButton rbtD;
    private javax.swing.JRadioButton rbtO;
    private javax.swing.JTable tbDatos;
    private javax.swing.JTextField txtNombreApellido;
    // End of variables declaration//GEN-END:variables
}
