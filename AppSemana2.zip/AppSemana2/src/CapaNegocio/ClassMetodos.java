
package CapaNegocio;

import javax.swing.JComboBox;

public class ClassMetodos implements intMetodos {

    @Override
    public void LlenarDistritos(JComboBox cboDistrito) {
        cboDistrito.addItem("Lima");
        cboDistrito.addItem("San Isidro");
        cboDistrito.addItem("Surco");
        cboDistrito.addItem("Barranco");
        cboDistrito.addItem("San Borja");
        cboDistrito.addItem("Jesús María");
        cboDistrito.addItem("Miraflores");
        cboDistrito.addItem("La Victoria");
        cboDistrito.addItem("Yanahuara");
        cboDistrito.addItem("San Martín de Porres");
    }

    @Override
    public double HallarSueldo(int ordenArea) {
        switch(ordenArea){
            case 0: return 2100;
            case 1: return 2200;
            case 2: return 2300;
            case 3: return 2400;
            case 4: return 2500;
            case 5: return 2600;
            case 6: return 2700;
            case 7: return 2800;
            case 8: return 2900;
            case 9: return 3000;
        }
        return 0;
    }

    @Override
    public double HallarDescuento(double sueldo) {
        return sueldo * 0.15;
    }

    @Override
    public double HallarTotal(double sueldo, double descuento) {
        return sueldo - descuento;
    }
    
}
