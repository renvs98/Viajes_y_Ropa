
package CapaNegocio;

import javax.swing.JComboBox;

public interface intMetodos {
    void LlenarDistritos(JComboBox cboDistrito);
    double HallarSueldo(int ordenArea);
    double HallarDescuento (double sueldo);
    double HallarTotal (double sueldo,double descuento);
}
