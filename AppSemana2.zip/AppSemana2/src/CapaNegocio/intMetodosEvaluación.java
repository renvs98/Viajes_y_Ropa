
package CapaNegocio;

import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public interface intMetodosEvaluación {
    void LlenarPais(JComboBox cboPais);
    void LlenarLista(int ordenPais,DefaultListModel modlstTuristico);
    String MostrarImagen(int ordenP,int ordenT);
    void Acoplar(String ximagen,JLabel lblFoto);
    void LlenarPersonas(JComboBox cboPersonas);
    double CostoLugar (int ordenP, int ordenT);
    double TotalCosto (int cantidadP, int costoT);
    double Descuento (int costoT);
    double PagoTotal (double costoT, int totalDescuento);
}
