
package CapaNegocio;

import java.awt.Dimension;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class ClassMetodosTarea implements intMetodosTarea {
    
    @Override
    //METODO ELEGIR PRENDA SEGUN VARON,MUJER,NIÑO
    public void ElegirPrenda(int ordenP, JComboBox cboPrenda) {
        cboPrenda.removeAllItems();
        switch (ordenP) {
            case 0: // Hombre
                cboPrenda.addItem("Buzo");
                cboPrenda.addItem("Casaca");
                cboPrenda.addItem("Pantalon");
                cboPrenda.addItem("Polo");
                break;
            case 1: // Mujer
                cboPrenda.addItem("Buzo");
                cboPrenda.addItem("Casaca");
                cboPrenda.addItem("Pantalon");
                cboPrenda.addItem("Polo");
                break;
            case 2: // Niños
                cboPrenda.addItem("Buzo");
                cboPrenda.addItem("Casaca");
                cboPrenda.addItem("Pantalon");
                cboPrenda.addItem("Polo");
                break;
        }
    }

    @Override    
    //METODO IMAGENES X PRENDA
    public String Imagenes(int ordenP, int ordenR) {
        if(ordenP==0){ // Hombre
            switch(ordenR){
                case 0 :return "Buzo-Hombre.png";
                case 1 :return "Casaca-Hombre.png";
                case 2 :return "Pantalon-Hombre.png";
                case 3 :return "Polo-Hombre.png";
            }
        }
        if(ordenP==1){ // Mujer
            switch(ordenR){
                case 0 :return "Buzo-Mujer.png";
                case 1 :return "Casaca-Mujer.png";
                case 2 :return "Pantalon-Mujer.png";
                case 3 :return "Polo-Mujer.png";
            }
        }
        if(ordenP==2){ // Niños
            switch(ordenR){
                case 0 :return "Buzo-Niños.png";
                case 1 :return "Casaca-Niños.png";
                case 2 :return "Pantalon-Niños.png";
                case 3 :return "Polo-Niños.png";
            }
        }
        return "";
    }
    
    @Override
    //METODO ACOPLAR IMAGENES EN LABEL
    public void Acoplar(String ximagen, JLabel lblFotoRopa) {
        ImageIcon imagenIcon = new ImageIcon(ximagen);
        Image imagen = imagenIcon.getImage();

        // Obtener dimensiones del JLabel
        int anchoLbl = lblFotoRopa.getWidth();
        int altoLbl = lblFotoRopa.getHeight();

        // Escalar la imagen manteniendo la proporción
        int anchoImg = imagenIcon.getIconWidth();
        int altoImg = imagenIcon.getIconHeight();
        double escalaAncho = (double) anchoLbl / anchoImg;
        double escalaAlto = (double) altoLbl / altoImg;
        double escala = Math.min(escalaAncho, escalaAlto);
        int nuevoAncho = (int) (anchoImg * escala);
        int nuevoAlto = (int) (altoImg * escala);

        // Crear un nuevo ImageIcon con la imagen escalada
        ImageIcon imagenEscaladaIcon = new ImageIcon(imagen.getScaledInstance(nuevoAncho, nuevoAlto, Image.SCALE_SMOOTH));

        // Asignar la imagen escalada al JLabel y centrarla
        lblFotoRopa.setIcon(imagenEscaladaIcon);
        lblFotoRopa.setHorizontalAlignment(JLabel.CENTER);
        lblFotoRopa.setVerticalAlignment(JLabel.CENTER);
        lblFotoRopa.setPreferredSize(new Dimension(nuevoAncho, nuevoAlto));
    }

    @Override
    //METODO PRECIO X PRENDA
    public double HallarPrecioVenta(int ordenP, int ordenR) {
    if(ordenP==0){ // Hombre
        switch(ordenR){
            case 0 :return 500;
            case 1 :return 600;
            case 2 :return 300;
            case 3 :return 400;
        }
    }
    if(ordenP==1){ // Mujer
        switch(ordenR){
            case 0 :return 500;
            case 1 :return 600;
            case 2 :return 500;
            case 3 :return 200;
        }
    }
    if(ordenP==2){ // Niños
        switch(ordenR){
            case 0 :return 100;
            case 1 :return 200;
            case 2 :return 300;
            case 3 :return 400;
        }
    }
    return 0;
    }

    @Override
    //METODO PRECIO*CANTIDAD
    public double HallarPrecioTotal(int PrecioVenta, int Cantidad) {
        return PrecioVenta*Cantidad;
    }
}