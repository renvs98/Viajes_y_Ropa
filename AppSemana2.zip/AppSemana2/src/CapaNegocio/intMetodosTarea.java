
package CapaNegocio;

import javax.swing.JComboBox;
import javax.swing.JLabel;

public interface intMetodosTarea {
    void ElegirPrenda(int ordenP,JComboBox cboPrenda);
    String Imagenes (int ordenP, int ordenR);
    void Acoplar (String ximagen,JLabel lblFotoRopa);
    double HallarPrecioVenta (int ordenP,int ordenR);
    double HallarPrecioTotal (int PrecioVenta, int Cantidad);
}
