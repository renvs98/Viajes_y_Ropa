
package CapaNegocio;

import java.awt.Image;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class ClassMetodosEvaluación implements intMetodosEvaluación {

    @Override
    public void LlenarPais(JComboBox cboPais) {
        cboPais.addItem("Perú");
        cboPais.addItem("Argentina");
        cboPais.addItem("España");
        cboPais.addItem("Italia");
    }

    @Override
    public void LlenarLista(int ordenPais, DefaultListModel modlstTuristico) {
        if(ordenPais==0){
            modlstTuristico.addElement("Cusco");
            modlstTuristico.addElement("Puno");
            modlstTuristico.addElement("Cajamarca");
            modlstTuristico.addElement("Huancayo");
        }
        if(ordenPais==1){
            modlstTuristico.addElement("Buenos Aires");
            modlstTuristico.addElement("Iguazú");
            modlstTuristico.addElement("Bariloche");
        }
        if(ordenPais==2){
            modlstTuristico.addElement("Barcelona");
            modlstTuristico.addElement("Madrid");
            modlstTuristico.addElement("Sevilla");
            modlstTuristico.addElement("Granada");
        }
        if(ordenPais==3){
            modlstTuristico.addElement("Roma");
            modlstTuristico.addElement("Florencia");
            modlstTuristico.addElement("Venecia");
        }
    }

    @Override
    public String MostrarImagen(int ordenP, int ordenT) {
    if(ordenP==0){ // Perú
        switch(ordenT){
            case 0 :return "Cusco.png";
            case 1 :return "Puno.png";
            case 2 :return "Cajamarca.png";
            case 3 :return "Huancayo.png";
        }
    }
    if(ordenP==1){ // Argentina
        switch(ordenT){
            case 0 :return "Buenos Aires.png";
            case 1 :return "Iguazú.png";
            case 2 :return "Bariloche.png";
        }
    }
    if(ordenP==2){ // España
        switch(ordenT){
            case 0 :return "Barcelona.png";
            case 1 :return "Madrid.png";
            case 2 :return "Sevilla.png";
            case 3 :return "Granada.png";
        }
    }
    if(ordenP==3){ // Italia
        switch(ordenT){
            case 0 :return "Roma.png";
            case 1 :return "Florencia.png";
            case 2 :return "Venecia.png";
        }
    }
    return "";
    }

    @Override
    public void Acoplar(String ximagen, JLabel lblFoto) {
        ImageIcon imagen = new ImageIcon(ximagen);
        Icon icon = new ImageIcon(imagen.getImage().getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_DEFAULT));
        lblFoto.setIcon(icon);
    }

    @Override
    public void LlenarPersonas(JComboBox cboPersonas) {
        for(int i = 1; i <= 10; i++){
            cboPersonas.addItem(String.valueOf(i));
        }
    }

    @Override
    public double CostoLugar(int ordenP, int ordenT) {
    if(ordenP==0){ // Perú
        switch(ordenT){
            case 0 :return 600;
            case 1 :return 700;
            case 2 :return 800;
            case 3 :return 900;
        }
    }
    if(ordenP==1){ // Argentina
        switch(ordenT){
            case 0 :return 1000;
            case 1 :return 1100;
            case 2 :return 1200;
        }
    }
    if(ordenP==2){ // España
        switch(ordenT){
            case 0 :return 1300;
            case 1 :return 1400;
            case 2 :return 1500;
            case 3 :return 1600;
        }
    }
    if(ordenP==3){ // Italia
        switch(ordenT){
            case 0 :return 1700;
            case 1 :return 1800;
            case 2 :return 1900;
        }
    }
    return 0;
    }    

    @Override
    public double TotalCosto(int cantidadP, int costoT) {
        return cantidadP*costoT;
    }

    @Override
    public double Descuento(int costoT) {
        return costoT*0.10;
    }

    @Override
    public double PagoTotal(double costoT, int totalDescuento) {
        return costoT-totalDescuento;
    }
    
}
